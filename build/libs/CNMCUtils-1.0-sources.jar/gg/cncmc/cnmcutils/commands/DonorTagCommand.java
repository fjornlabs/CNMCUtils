package gg.cncmc.cnmcutils.commands;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.luckperms.api.LuckPerms;
import net.luckperms.api.LuckPermsProvider;
import net.luckperms.api.node.NodeType;
import net.luckperms.api.node.types.InheritanceNode;
import net.minecraft.class_1657;
import net.minecraft.class_2168;
import net.minecraft.class_2561;

import static gg.cncmc.cnmcutils.utils.LuckPermsHook.hasPermission;
import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

public class DonorTagCommand {
    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(method_9247("donortag")
                    .requires(src -> hasPermission(src, "cnmc.donortag"))
                    .then(method_9247("clear")
                            .executes(DonorTagCommand::clear))
                    .then(method_9244("tag", StringArgumentType.word())
                            .suggests((context, builder) -> {
                                // Add your autocomplete suggestions here
                                builder.suggest("Emperor");
                                builder.suggest("Empress");
                                builder.suggest("Governor");
                                builder.suggest("Lord");
                                builder.suggest("King");
                                builder.suggest("His Grace");
                                builder.suggest("Her Grace");
                                builder.suggest("Lady");
                                builder.suggest("Sir");
                                builder.suggest("Dame");
                                builder.suggest("Baron");
                                builder.suggest("Baroness");
                                builder.suggest("Duke");
                                builder.suggest("Duchess");
                                builder.suggest("Prince");
                                builder.suggest("Princess");
                                builder.suggest("Count");
                                builder.suggest("Countess");
                                builder.suggest("President");
                                builder.suggest("Vice President");
                                builder.suggest("Senator");
                                builder.suggest("Minister");
                                builder.suggest("Margrave");
                                builder.suggest("Marquis");
                                builder.suggest("Holiness");
                                builder.suggest("Vizier");
                                builder.suggest("Shah");
                                builder.suggest("Sheik");
                                builder.suggest("Tsar");
                                builder.suggest("Prophet");
                                builder.suggest("CEO");
                                builder.suggest("Representative");
                                builder.suggest("Speaker");
                                builder.suggest("General");
                                builder.suggest("Commander");
                                builder.suggest("Admiral");
                                builder.suggest("Field Marshal");
                                builder.suggest("Khan");
                                builder.suggest("Khagan");
                                builder.suggest("Chancellor");
                                builder.suggest("Burgermeister");
                                builder.suggest("Burgrave");
                                builder.suggest("General Secretary");
                                builder.suggest("Supreme Leader");
                                builder.suggest("Mister");
                                builder.suggest("Mistress");
                                builder.suggest("Madam");
                                builder.suggest("Prime Minister");
                                builder.suggest("Queen");
                                builder.suggest("Judge");
                                builder.suggest("Builder");
                                builder.suggest("Warrior");
                                builder.suggest("Master");
                                builder.suggest("Chieftan");
                                builder.suggest("Chieftess");
                                builder.suggest("Dr.");

                                return builder.buildFuture();
                            })
                            .executes(DonorTagCommand::execute)
            ));
        });
    }

    private static int execute(CommandContext<class_2168> ctx) {
        class_2168 source = ctx.getSource();
        String tag = StringArgumentType.getString(ctx, "tag");

        if (!(source.method_9228() instanceof class_1657 player)) {
            source.method_9226(() -> class_2561.method_43470("Only players can use this!"), false);
            return 0;
        }

        LuckPerms luckPerms = LuckPermsProvider.get();

        luckPerms.getUserManager().loadUser(player.method_5667()).thenAcceptAsync(user -> {
            if (user == null) return;

            user.data().clear(NodeType.INHERITANCE.predicate(
                    node -> node.getGroupName().startsWith("donor-")
            ));

            InheritanceNode newTag = InheritanceNode.builder("donor-" + tag).build();
            user.data().add(newTag);

            luckPerms.getUserManager().saveUser(user);
        });

        return 1;
    }

    private static int clear(CommandContext<class_2168> ctx) {
        class_2168 src = ctx.getSource();

        if (!(src.method_9228() instanceof class_1657 player)) {
            src.method_9226(() -> class_2561.method_43470("Only players can use this!"), false);
            return 0;
        }

        LuckPerms luckPerms = LuckPermsProvider.get();

        luckPerms.getUserManager().loadUser(player.method_5667()).thenAcceptAsync(user -> {
            if (user == null) return;

            user.data().clear(NodeType.INHERITANCE.predicate(
                    node -> node.getGroupName().startsWith("donor-")
            ));
        });

        return 1;
    }
}
