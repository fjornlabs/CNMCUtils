package gg.cncmc.cnmcutils.commands;

import com.mojang.brigadier.context.CommandContext;
import gg.cncmc.cnmcutils.CNMCUtils;
import gg.cncmc.cnmcutils.config.VoteConfig;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_5250;
import net.minecraft.text.*;

import static net.minecraft.class_2170.*;

public class VoteCommand {

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(method_9247("vote")
                    .executes(VoteCommand::execute)
                    .then(method_9247("reload")
                            .requires(src -> src.method_9259(2)) // ops only
                            .executes(VoteCommand::reload)
                    )
            );
        });
    }

    private static int execute(CommandContext<class_2168> context) {
        VoteConfig cfg = CNMCUtils.voteconfig;
        class_2168 source = context.getSource();

        source.method_9226(() ->
                class_2561.method_43470(cfg.header).method_27695(class_124.method_533(cfg.headerColor), class_124.field_1067), false);

        for (VoteConfig.VoteLink link : cfg.links) {
            class_5250 label = class_2561.method_43470("[" + link.label + "] ")
                    .method_27692(class_124.method_533(cfg.labelColor));

            class_5250 clickable = class_2561.method_43470("[Click here]")
                    .method_27695(class_124.method_533(cfg.clickColor), class_124.field_1073)
                    .method_27694(style -> style
                            .method_10958(new class_2558(class_2558.class_2559.field_11749, link.url))
                            .method_10949(new class_2568(
                                    class_2568.class_5247.field_24342,
                                    class_2561.method_43470(link.url).method_27692(class_124.field_1080)
                            ))
                    );

            class_5250 line = label.method_10852(clickable);
            source.method_9226(() -> line, false);
        }

        source.method_9226(() ->
                class_2561.method_43470(cfg.footer).method_27692(class_124.method_533(cfg.footerColor)), false);
        return 1;
    }

    private static int reload(CommandContext<class_2168> context) {
        CNMCUtils.voteconfig = VoteConfig.load();
        context.getSource().method_9226(() ->
                class_2561.method_43470("[Vøte] Config reloaded!").method_27692(class_124.field_1060), false);
        return 1;
    }
}