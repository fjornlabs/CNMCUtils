package gg.cncmc.cnmcutils.utils;

import net.luckperms.api.LuckPermsProvider;
import net.luckperms.api.model.user.User;
import net.minecraft.class_2168;

public class LuckPermsHook {
    public static boolean hasPermission(class_2168 source, String permission) {
        try {
            User user = LuckPermsProvider.get()
                    .getUserManager()
                    .getUser(source.method_44023().method_5667());

            if (user == null) return source.method_9259(2); // also fallback here

            return user.getCachedData()
                    .getPermissionData()
                    .checkPermission(permission)
                    .asBoolean();
        } catch (Exception e) {
            return source.method_9259(2); // fallback if LuckPerms isn't present
        }
    }
}